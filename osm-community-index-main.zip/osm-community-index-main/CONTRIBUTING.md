# Contributing

We're always looking for help!

- Read [the Code of Conduct](CODE_OF_CONDUCT.md) and remember to be kind to one another.
- See [the project wiki](https://github.com/osmlab/osm-community-index/wiki) for info about how to contribute to this index.

If you have any questions or want to reach out to a maintainer, ping
[@bhousel][@bhousel] or [@awiseman][@awiseman] on:
- [OpenStreetMap US Slack](https://slack.openstreetmap.us/) (`#general` channel)

[@bhousel]: https://github.com/bhousel
[@awiseman]: https://github.com/awiseman
