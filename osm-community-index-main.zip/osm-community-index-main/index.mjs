export { resolveStrings } from './lib/resolve_strings.js';
export { simplify } from './lib/simplify.js';
